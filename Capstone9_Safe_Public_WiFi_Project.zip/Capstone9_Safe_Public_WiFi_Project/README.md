# CAPSTONE 9 — Safe Public Wi-Fi and Basic Network Security Guide

**Audience:** College students using campus, café and hostel Wi-Fi  
**Purpose:** Explain common public Wi-Fi risks and safe habits using only a local lab and a clearly synthetic sample capture.

## Project contents
- `report/research_report.md` — research summary, scope, sources and conclusions
- `checklists/safe_wifi_checklist.md` — practical before/during/after checklist
- `guide/900_word_guide.md` — plain-language HTTP vs HTTPS, DNS and VPN guide
- `packet_analysis/` — synthetic sample packet CSV, Wireshark notes and interpretation
- `infographic/5_things_before_public_wifi.png` — ready-to-use infographic
- `presentation/capstone9_presentation.pptx` — six-slide presentation
- `quiz/quiz_and_answer_key.md` — 10 questions with answers and explanations
- `automation/summarize_capture.py` — Python script summarising protocol counts from CSV
- `prompts/prompt_library.md` — documented prompts for research, analysis, quiz and presentation
- `verification/verification_report.md` — fact-check and AI-output verification record
- `verification/before_after_analysis.md` — example of improving an AI response through verification
- `demo/final_demo.md` — short demonstration script
- `data/` — synthetic capture data and sample output

## Safety and ethical scope
This project does **not** capture anyone else's traffic, scan public networks, or demonstrate credential theft. The included packet data is synthetic and designed for learning. If using Wireshark, open only the supplied sample file or traffic from a lab device/network you own or have explicit permission to test.

## Quick start
1. Read `report/research_report.md` and `guide/900_word_guide.md`.
2. Open `packet_analysis/sample_capture.csv` in a spreadsheet or use the supplied synthetic `sample_capture.pcap` in Wireshark.
3. Run: `python automation/summarize_capture.py data/sample_capture.csv`
4. Review the six-slide deck and infographic.
5. Take the quiz, then compare with the answer key.

## Requirements
- Python 3.9+ (script uses only the standard library)
- Optional: Wireshark for inspecting the supplied synthetic PCAP
- Optional: PowerPoint or LibreOffice Impress for the slide deck

## Important note
The sample capture is illustrative, not evidence of a real network. Protocols and fields may be simplified. Validate any packet-level interpretation directly in Wireshark and distinguish observations from assumptions.
