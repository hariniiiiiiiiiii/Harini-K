# A Student-Friendly Guide to HTTP, HTTPS, DNS and VPNs

Public Wi-Fi is useful at college, in cafés, libraries and hostels. It is also a shared environment where you may not control the router or know every device connected to it. Understanding a few networking basics helps you make safer choices without becoming a network engineer.

## HTTP and HTTPS

HTTP is the set of rules a browser uses to request web content. In plain HTTP, the connection does not provide encryption by itself. Depending on the network position and other protections, someone able to observe or interfere with that traffic may be able to read or change information. For that reason, do not enter passwords or private details into a site that uses plain HTTP.

HTTPS is HTTP carried inside Transport Layer Security (TLS). TLS is designed to protect confidentiality (outsiders should not be able to read the protected content), integrity (changes should be detected) and authentication (the browser checks that the server presents a certificate valid for the requested domain). Use HTTPS and keep browser security warnings enabled.

HTTPS is important, but it is not a guarantee that a website is honest. A phishing page can also use HTTPS. The padlock generally means the connection is encrypted and the certificate checks passed; it does not mean the website deserves your trust. Check the domain spelling, be cautious of urgent messages and avoid following unexpected login links.

## DNS: finding a website

People remember names such as `example.com`, while networks route traffic using IP addresses. The Domain Name System (DNS) helps translate a domain name into the address needed to connect. A device typically asks a DNS resolver for this information.

Traditional DNS queries are not encrypted by the DNS protocol itself, so a network operator or another party in a suitable position may learn which names are being looked up. DNS over TLS and DNS over HTTPS can encrypt the connection between your device and a compatible resolver. However, encrypted DNS does not hide all activity: the resolver receives the queries, and other information such as destination IP addresses may still be observable. DNS security depends on the device, browser, resolver and network configuration.

## VPN: an encrypted tunnel

A Virtual Private Network (VPN) creates a protected tunnel between your device and a VPN gateway. On public Wi-Fi, this can make it harder for other local network users to inspect the contents of traffic carried inside the tunnel. A workplace or college may provide its own VPN; a commercial provider may offer one for personal use.

A VPN changes the trust relationship rather than making risk disappear. The VPN provider can potentially observe metadata and traffic that is not separately encrypted after it leaves the tunnel. HTTPS remains important even when a VPN is active. A VPN does not stop you from typing your password into a fake website, downloading malware, sharing private information with an app, or being tracked by a logged-in service. Choose a provider carefully, download software from the official source and avoid unknown VPN apps promoted by a hotspot.

## Common public Wi-Fi risks

An **evil twin** is a look-alike hotspot that imitates a legitimate network name. A **rogue access point** is an unauthorised wireless access point. A **man-in-the-middle attempt** tries to position an attacker between two communicating parties. **DNS manipulation** can attempt to direct a domain lookup to an incorrect address. **Phishing** tricks people into revealing information or installing something unsafe. These are concepts to recognise, not activities to test against networks without permission.

Modern HTTPS and careful certificate validation reduce the chance that an intermediary can silently read or alter protected web content. If a browser reports a certificate problem, do not ignore it. Disconnect and ask the network operator or IT team for help.

## A simple routine for students

Before connecting, confirm the exact network name with staff or campus IT. Turn off automatic joining of open networks and keep your device and browser updated. Set the network profile to public and disable file sharing or discovery features that you do not need. Do not install a certificate, app, configuration profile or extension just because a portal says it is required.

While browsing, use HTTPS, check domain spellings and avoid unexpected links. Use multi-factor authentication (MFA), unique passwords and a password manager. If the network seems suspicious, postpone sensitive activity or use a trusted mobile connection. A VPN can be useful, but do not treat it as a replacement for HTTPS or cautious behaviour.

After using the hotspot, disconnect and forget the network if you will not need it again. Sign out of accounts on shared devices. If you think you entered a password on a fake page, use a trusted connection to change it and review active sessions.

## Final takeaway

Safe public Wi-Fi is about layers. Confirm the network, keep devices updated, use HTTPS, protect accounts, limit sharing and be wary of unexpected prompts. DNS helps names find addresses; a VPN protects a tunnel to its operator; HTTPS protects a browser-to-site connection. None can replace good judgement. For learning, analyse only a provided sample capture or traffic from a lab you own or have permission to inspect.
