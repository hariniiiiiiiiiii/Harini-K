# Research Report: Safe Public Wi-Fi and Basic Network Security

## 1. Aim
To explain public Wi-Fi risks and practical protection habits for college students, using trusted public guidance and a synthetic packet sample in a controlled learning environment.

## 2. Background
Campus, café, library and hostel Wi-Fi are convenient, but a user may not know who operates a hotspot, whether its configuration is safe, or whether other users are on the same local network. Risks include connecting to a look-alike hotspot, using unencrypted websites, installing unexpected certificates or profiles, ignoring security warnings, and exposing a device that shares files or accepts incoming connections. A padlock/HTTPS connection protects the connection to a website, but does not prove that the website itself is honest.

## 3. Target audience
College students who use shared Wi-Fi for learning platforms, email, social media, cloud storage and online payments.

## 4. Key concepts
- **HTTP:** Web traffic without transport encryption; observers on the path may be able to read or alter content.
- **HTTPS:** HTTP protected by TLS. It helps provide confidentiality, integrity and server authentication when certificates are validated correctly.
- **DNS:** A naming system that helps a device find the network address for a domain. DNS privacy depends on the resolver and whether encrypted DNS is used; HTTPS does not automatically hide every DNS lookup.
- **VPN:** An encrypted tunnel from the device to a VPN provider or organisation's VPN gateway. It can reduce exposure on a local network, but shifts trust to the VPN operator and does not make phishing, malware or unsafe downloads harmless.
- **Captive portal:** A sign-in or terms page commonly used by public hotspots. A portal is not the same as end-to-end encryption for every later connection.
- **Common attack concepts:** Evil-twin/look-alike hotspot, rogue access point, DNS manipulation, man-in-the-middle attempts, session theft where protections are weak, and phishing. This report describes these conceptually and gives no instructions for carrying them out.

## 5. Research approach
The project uses official or primary reference material from CISA, CERT-In, Wireshark, IETF and Mozilla. Sources were selected because they provide security guidance or technical documentation. The supplied sample packet data is synthetic; it is not a capture from a public hotspot. Any AI-generated explanation should be treated as a draft and checked against source material and the actual packet fields.

## 6. Findings and safe habits
1. Prefer a trusted network and confirm the exact hotspot name with staff or campus IT.
2. Keep the operating system, browser and apps updated.
3. Use HTTPS websites and never bypass certificate or browser security warnings.
4. Use a reputable VPN when appropriate, especially for sensitive activity on networks you do not administer; understand that the VPN provider becomes a party you trust.
5. Disable automatic joining of open networks and forget networks you no longer use.
6. Turn off file sharing and unnecessary discovery features on public networks; use the device's public-network profile.
7. Avoid installing unknown apps, certificates, configuration profiles or browser extensions prompted by a hotspot.
8. Use multi-factor authentication and unique passwords; a password manager can help.
9. Sign out of shared devices and sensitive services when finished.
10. For sensitive tasks, use a trusted mobile connection if available.

## 7. Sample packet analysis summary
The project includes a small synthetic capture with DNS, TCP, TLS and HTTP-labelled records. Its purpose is to practise identifying protocols and distinguishing visible metadata from encrypted application content. It does not include real credentials or another person's traffic. See `packet_analysis/packet_analysis_notes.md`. Packet labels alone are not proof that a site is malicious or safe; interpret context and verify with Wireshark's decoded fields.

## 8. Limitations
- The capture is synthetic and cannot represent every Wi-Fi configuration or attack.
- A packet capture can omit context, be truncated, or be affected by offloading and capture location.
- A VPN protects traffic only between the device and VPN endpoint; traffic beyond that endpoint and endpoint compromise remain concerns.
- HTTPS protects transport, not user judgement or website legitimacy.
- AI outputs may hallucinate protocol details, overstate VPN protection or confuse DNS with HTTP. Verify claims before submission.

## 9. Conclusion
Public Wi-Fi is not automatically unsafe, and a VPN is not a magic shield. The most effective approach combines trusted networks, HTTPS, current software, sensible sharing settings, strong authentication, cautious handling of prompts and downloads, and verification of unusual warnings. Use only your own or authorised lab traffic for packet analysis.

## 10. References
1. CISA, *Securing Wireless Networks*: https://www.cisa.gov/news-events/news/securing-wireless-networks
2. CERT-In, advisories and security guidelines: https://www.cert-in.org.in/
3. Wireshark User's Guide: https://www.wireshark.org/docs/wsug_html_chunked/
4. IETF RFC 8446, *The Transport Layer Security (TLS) Protocol Version 1.3*: https://www.rfc-editor.org/rfc/rfc8446
5. IETF RFC 7858, *Specification for DNS over TLS*: https://www.rfc-editor.org/rfc/rfc7858
6. Mozilla Support, *HTTPS-Only Mode in Firefox*: https://support.mozilla.org/en-US/kb/https-only-p mode-firefox
7. CISA, Secure Our World: https://www.cisa.gov/secure-our-world

**Reference note:** Confirm the current wording and availability of each source before final submission. URLs are provided as starting points for primary-source verification.
