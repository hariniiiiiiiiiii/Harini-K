# Public Wi-Fi Security Quiz

Choose one answer for each question.

1. What does HTTPS primarily add to HTTP?
   A. Guaranteed website honesty  B. TLS protection for the connection  C. A guarantee against malware  D. Complete anonymity

2. What does DNS help a device do?
   A. Translate domain names into network information such as IP addresses  B. Remove viruses  C. Encrypt every app  D. Verify a website's intentions

3. What is a look-alike or “evil twin” hotspot?
   A. A hotspot that resembles a legitimate network to mislead users  B. A stronger password  C. A VPN protocol  D. A browser update

4. What is a sensible response to a browser certificate warning on public Wi-Fi?
   A. Ignore it  B. Enter credentials quickly  C. Stop and verify through a trusted channel  D. Install any certificate offered

5. Which statement about VPNs is most accurate?
   A. They prevent all phishing  B. They make all users anonymous  C. They create a protected tunnel to a VPN endpoint, with limitations  D. They replace HTTPS

6. Why should automatic joining of open networks be disabled?
   A. To reduce accidental connections to untrusted hotspots  B. To improve screen brightness  C. To disable MFA  D. To delete files

7. Which is a good account-protection habit?
   A. Reuse one password  B. Use unique passwords and MFA  C. Share passwords with classmates  D. Disable updates

8. What can a TLS packet observation tell you?
   A. The site is definitely safe  B. The user has no malware  C. A TLS exchange may be occurring; context and decoded fields still matter  D. Every application message is readable

9. What should you do before analysing a packet capture?
   A. Capture nearby users without telling them  B. Use supplied sample data or traffic you are authorised to inspect  C. Publish all IP addresses  D. Assume every packet is malicious

10. What does a captive portal usually provide?
    A. A Wi-Fi sign-in or terms page  B. Guaranteed end-to-end encryption for all traffic  C. A malware scanner for every device  D. A VPN provider

## Answer key with explanations
1. **B** — HTTPS uses TLS to protect the connection; it does not guarantee honesty.
2. **A** — DNS helps resolve names to network records, commonly IP addresses.
3. **A** — Look-alike hotspots imitate trusted network names.
4. **C** — Do not bypass certificate warnings; verify with the network operator or IT.
5. **C** — A VPN protects the tunnel to its endpoint, but other risks remain.
6. **A** — This reduces accidental connections to unknown networks.
7. **B** — Unique passwords and MFA reduce account-compromise risk.
8. **C** — TLS metadata does not prove site safety or reveal all encrypted content.
9. **B** — Permission and privacy are essential.
10. **A** — Captive portals handle access/login terms; they are not a guarantee of encryption for every later connection.
