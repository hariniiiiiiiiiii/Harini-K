# Prompt Library and AI Use Log

Use these prompts with any AI tool, then independently verify the output. Do not upload real packet captures containing personal or sensitive traffic to public AI services.

## Prompt 1 — Research plan
**Prompt:** “Act as a cybersecurity educator for college students. Create a source-led outline on public Wi-Fi risks, HTTPS, DNS and VPNs. Use only claims that can be checked against CISA, CERT-In, IETF, Mozilla or Wireshark documentation. Separate established facts from recommendations, include source URLs, and flag anything that needs verification. Do not provide attack instructions.”

**Expected output:** Topic outline, source candidates, questions to verify.

## Prompt 2 — Explain a concept
**Prompt:** “Explain HTTP versus HTTPS, DNS and VPNs in plain language for a first-year college student. Use one everyday analogy for each, state one limitation of each technology, and avoid saying a VPN makes a user completely anonymous or safe.”

## Prompt 3 — Sample packet interpretation
**Prompt:** “Using only the supplied synthetic CSV fields, summarise the protocols, ports and lengths. For each statement, label it Observation or Interpretation. Do not infer malicious intent, real identities, credentials or the content of encrypted traffic. Tell me what must be checked in Wireshark.”

## Prompt 4 — Safety checklist
**Prompt:** “Create a concise public Wi-Fi checklist for students with before, during and after sections. Include HTTPS warnings, look-alike hotspots, updates, sharing settings, MFA, VPN limitations and ethical behaviour. Do not overstate protection.”

## Prompt 5 — Quiz
**Prompt:** “Write 10 multiple-choice questions for college students about public Wi-Fi, HTTPS, DNS, VPNs, phishing and packet-capture ethics. Provide one correct answer and a short explanation per question. Avoid operational attack instructions.”

## Prompt 6 — Presentation
**Prompt:** “Create a six-slide presentation outline: title/audience, common risks, HTTPS/DNS/VPN basics, safe habits, synthetic packet sample, and ethics/takeaways. Use concise bullets and a calm educational tone.”

## Prompt 7 — Verification / red-team the answer
**Prompt:** “Review this draft for factual errors, overclaims, unsafe advice and unsupported statements. Check especially whether it claims HTTPS proves a site is trustworthy, whether it says a VPN prevents phishing, whether it confuses DNS encryption with full anonymity, and whether it encourages unauthorised packet capture. Return a table of claim, concern, correction and verification source.”

## AI tool usage record
For final submission, fill in the actual tool names, date, prompt, output excerpt, changes made and verification source for each tool you personally used. Do not claim a tool was used unless you actually used it. Suggested free tools from the assignment include ChatGPT, Gemini, Claude, Perplexity, NotebookLM and Gamma; availability and free limits can change.
