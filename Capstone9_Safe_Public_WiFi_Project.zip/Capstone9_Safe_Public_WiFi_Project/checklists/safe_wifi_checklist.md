# Safe Public Wi-Fi Checklist

## Before connecting
- [ ] Confirm the exact network name with campus IT, café staff or the host.
- [ ] Prefer a trusted network; avoid look-alike names and unexpected open hotspots.
- [ ] Disable automatic connection to open Wi-Fi.
- [ ] Update your OS, browser and important apps.
- [ ] Use a screen lock and strong, unique passwords; enable MFA.
- [ ] Keep file sharing, AirDrop/Nearby Share and network discovery off unless needed.
- [ ] If using a VPN, install it from its official source and understand who operates it.

## While connected
- [ ] Use HTTPS and check for unexpected browser certificate/security warnings.
- [ ] Never click through a warning just to reach a page.
- [ ] Do not install unknown certificates, apps, profiles or extensions to access Wi-Fi.
- [ ] Treat captive-portal pages cautiously; enter only the information genuinely required.
- [ ] Avoid sensitive transactions if the network or device seems suspicious.
- [ ] Do not assume a VPN protects against phishing, malware or fake websites.
- [ ] Lock your screen when stepping away.

## After use
- [ ] Disconnect and select “forget” for networks you do not need to remember.
- [ ] Sign out of accounts on shared devices.
- [ ] Review unexpected login alerts and report suspicious activity to IT.
- [ ] If you entered a password on a suspicious page, change it from a trusted connection and review active sessions.

## Remember
HTTPS protects the connection to a site, not the truthfulness of the site. A VPN changes who you trust; it does not eliminate all risk.
