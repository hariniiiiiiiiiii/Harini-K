# Before/After Analysis: Improving an AI Explanation

## Initial draft (intentionally flawed example)
“Public Wi-Fi is dangerous. A VPN makes you anonymous and prevents hackers from stealing your data. HTTPS websites are always trustworthy. DNS is encrypted automatically. You can capture nearby traffic to see what people are doing.”

## Problems identified
1. “A VPN makes you anonymous” overstates privacy; a provider may see metadata and account activity can identify users.
2. “Prevents hackers” is absolute and ignores phishing, malware, endpoint compromise and traffic beyond the VPN endpoint.
3. “HTTPS websites are always trustworthy” confuses connection encryption with site legitimacy.
4. “DNS is encrypted automatically” is configuration-dependent.
5. Capturing other people's traffic without permission is unethical and may be unlawful.

## Corrected version
“Public Wi-Fi can be used more safely with sensible precautions. HTTPS helps protect the connection between a browser and a website, but it does not prove that the site is legitimate. A VPN can protect traffic between your device and its VPN gateway, but it does not stop phishing or malware and it shifts some trust to the VPN provider. DNS privacy depends on the resolver and whether encrypted DNS is configured. For packet-analysis practice, use supplied sample files or traffic from a lab you own or have permission to inspect.”

## What changed
The corrected version replaces absolute claims with scoped claims, distinguishes encryption from trustworthiness, names limitations, and removes unsafe instructions. These changes reflect responsible AI use: treat AI output as a draft, check claims against reliable sources, and correct errors before publication.
