# Source Register

| Source | Why it is relevant | What to verify |
|---|---|---|
| CISA — Securing Wireless Networks | Wireless security recommendations | Current page title and recommendations |
| CERT-In | Indian cybersecurity advisories and guidance | Search for current user-facing guidance relevant to Wi-Fi and phishing |
| Wireshark User's Guide | Packet list, filters and capture interpretation | Current UI/filter syntax and packet details |
| IETF RFC 8446 | TLS 1.3 protocol specification | TLS security properties and scope |
| IETF RFC 7858 | DNS over TLS specification | Encrypted DNS scope and limitations |
| Mozilla Support — HTTPS-Only Mode | Browser-side HTTPS protection | Current Firefox behaviour and warnings |

## Evidence log template
For each source used in your final submission, record:
- Access date:
- Exact title:
- URL:
- Claim supported:
- Relevant section/paragraph:
- Any limitation or caveat:
