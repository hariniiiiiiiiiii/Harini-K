# Verification Report

## Review method
The project was checked against primary/official source starting points listed in the research report. The synthetic packet dataset was reviewed for privacy and safety: it uses documentation IP ranges (192.0.2.0/24 and 198.51.100.0/24), no real user names, no credentials and no real capture provenance.

## Claim checks
| Claim | Review result | Safe wording |
|---|---|---|
| HTTPS encrypts web traffic | Generally correct when TLS is correctly negotiated | HTTPS protects the browser-to-site connection using TLS; it does not prove the site is honest. |
| VPN makes public Wi-Fi safe | Overbroad if stated this way | A VPN encrypts traffic to its gateway, but the provider becomes trusted and phishing/malware remain possible. |
| DNS is always private | Incorrect | Traditional DNS may be observable; encrypted DNS protects the client-to-resolver connection but has limits. |
| A TLS packet means a site is safe | Incorrect | TLS indicates a protected session may be in use; it is not a reputation or safety verdict. |
| A packet capture can reveal all content | Incorrect | Encryption, capture position and protocol details limit what can be observed. |
| It is acceptable to capture nearby users' traffic for practice | Unethical and potentially unlawful | Use provided sample files or traffic you own/have explicit permission to inspect. |

## Technical caveats
- The CSV is a teaching summary, not a full forensic record.
- The included PCAP is deliberately minimal and includes synthetic UDP payloads; Wireshark may label these as generic data rather than DNS because they are not full standards-compliant DNS messages.
- Therefore, use the CSV to practise protocol-count automation and the PCAP to practise opening a capture, not as proof that every CSV row maps to a packet in the PCAP.
- If a real authorised capture is used in class, replace these notes with observations actually seen in Wireshark and remove sensitive information before sharing.

## Before submission
- [ ] Open the PCAP in Wireshark and record the exact fields you observe.
- [ ] Open every reference URL and verify current titles/content.
- [ ] Add the actual AI tools used and sample prompts/output excerpts.
- [ ] Correct any AI explanation that disagrees with primary documentation.
- [ ] Do not represent synthetic data as a real capture.
