#!/usr/bin/env python3
"""Summarise protocol counts and byte totals from the project's CSV sample.
Usage: python automation/summarize_capture.py data/sample_capture.csv
Uses only Python's standard library. CSV values are illustrative labels, not ground truth.
"""
import csv
import sys
from collections import Counter, defaultdict

def main(path):
    counts = Counter()
    bytes_by_protocol = defaultdict(int)
    total_bytes = 0
    frames = 0
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = {"protocol", "length_bytes"}
        if not required.issubset(reader.fieldnames or []):
            raise SystemExit("CSV must contain protocol and length_bytes columns.")
        for row in reader:
            protocol = (row.get("protocol") or "UNKNOWN").strip().upper()
            try:
                length = int(row.get("length_bytes") or 0)
            except ValueError:
                length = 0
            counts[protocol] += 1
            bytes_by_protocol[protocol] += length
            total_bytes += length
            frames += 1
    print(f"Frames summarised: {frames}")
    print(f"Total listed bytes: {total_bytes}")
    print("\nProtocol summary:")
    print(f"{'Protocol':<12}{'Frames':>8}{'Bytes':>12}")
    for protocol in sorted(counts):
        print(f"{protocol:<12}{counts[protocol]:>8}{bytes_by_protocol[protocol]:>12}")
    print("\nNote: summaries describe the supplied CSV labels only; they do not prove a network is safe or unsafe.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python automation/summarize_capture.py path/to/sample_capture.csv")
    main(sys.argv[1])
