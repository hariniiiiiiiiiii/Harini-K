# Packet Analysis Notes — Synthetic Sample

## Ethical statement
This sample is synthetic. It is not captured from a real person, campus, café or hostel. Never capture other people's traffic or attempt to intercept credentials. Use only supplied samples or authorised lab traffic.

## How to inspect
1. Open `sample_capture.pcap` in Wireshark.
2. Use the packet list and packet-details pane to inspect Ethernet/IP/TCP and the protocol labels.
3. Use display filters such as `dns`, `tcp`, `tls`, or `http` to focus on protocol types.
4. Compare Wireshark's decoded view with `sample_capture.csv`. Some fields are intentionally simplified for a beginner exercise.
5. Do not infer malicious activity from a protocol name alone.

## Illustrative observations
- DNS records show example domain lookups. In ordinary DNS, query names may be visible to parties able to observe that traffic.
- TCP records show connection setup/traffic metadata such as source and destination ports.
- TLS records indicate a protected session may be established; packet metadata can remain visible even when application content is encrypted.
- The HTTP-labelled record is an intentionally simplified educational example. Real packet decoding depends on the actual bytes and protocol framing.
- The sample contains no real credentials or personal information.

## Questions to answer
1. Which protocols appear in the sample?
2. Which fields are metadata (addresses, ports, timestamps)?
3. What does a TLS record suggest, and what does it not prove?
4. Why should a protocol label alone not be used to conclude that a host is malicious?
5. What ethical rule applies before capturing traffic?

## Verification warning
A CSV description is not a substitute for inspecting the actual packet bytes. If Wireshark decodes a field differently, record the observed result and correct your notes.
