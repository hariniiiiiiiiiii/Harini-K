# Final Demo Script (3–5 minutes)

1. **Introduce the problem (30 seconds):** Students often connect to campus, café and hostel Wi-Fi without checking the network or understanding what HTTPS and VPNs do.
2. **Show the checklist (45 seconds):** Highlight confirming the SSID, updating devices, using HTTPS, MFA and disabling sharing.
3. **Explain the guide (45 seconds):** HTTPS protects the browser-to-site connection; DNS resolves names; a VPN protects a tunnel to its gateway, with limitations.
4. **Open the sample capture (60 seconds):** Show `packet_analysis/sample_capture.pcap` in Wireshark. State clearly that it is synthetic. Compare it with the CSV and point out protocol labels/metadata.
5. **Run the automation (30 seconds):** `python automation/summarize_capture.py data/sample_capture.csv`
6. **Show responsible AI use (45 seconds):** Present the before/after analysis and explain how an overconfident draft was corrected using reliable sources.
7. **Close (20 seconds):** Safe habits work in layers. Only analyse traffic you own or are authorised to inspect.
